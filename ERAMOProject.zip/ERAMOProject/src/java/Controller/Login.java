/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Data.UtenteDao;
import Model.Utente;
import Utility.TemplateResult;
import freemarker.template.TemplateException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author tom
 */
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws IOException if an I/O error occurs
     */
    
    

    protected void action_error(HttpServletRequest request, HttpServletResponse response) throws IOException ,TemplateException{
    
           TemplateResult template = new TemplateResult(request.getServletContext());
           
           Map data = template.getRequestDataModel(request);
           data.put("login", false);
           template.process("listagiochi.html",data, response.getWriter());
    }
    
    protected void action_success(String username,String password,HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, TemplateException{
    
        
        
      
        
        UtenteDao userDao = new UtenteDao();
        
        boolean log = userDao.checkLogin(username, password);
        
        System.out.println(log);
        
        if( log)
        {
           Utente user = userDao.recuperaUtente(username);
        
            HttpSession sessione = request.getSession(true);
            
            sessione.setAttribute("username", user.getUsername());
        
            sessione.setAttribute("gruppo", user.getRuolo());
            
            sessione.setAttribute("login",false);
            /*
            TemplateResult template = new TemplateResult(request.getServletContext());
           
             Map data = template.getRequestDataModel(request);
            
             data.put("username",user.getUsername());
             
             template.process("login.html",data, response.getWriter());*/
            
            response.sendRedirect("Home");
        }
        
        else
        {
            action_error(request, response);
        }
        
    }
    
    
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException, TemplateException {
        
            response.setContentType("text/html;charset=UTF-8");
        
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            
            if((username!= null && !username.isEmpty() && (password != null && !password.isEmpty()))){
                action_success(username , password , request , response);
            }
            else action_error(request , response);
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TemplateException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TemplateException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
