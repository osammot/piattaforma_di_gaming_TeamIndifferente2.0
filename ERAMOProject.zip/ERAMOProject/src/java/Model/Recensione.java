
package Model;

import java.util.Date;


public class Recensione   {
    
    
    private String username;
    
    private Date dataInserimentoRecensione;
    
    private String titoloRecensione;
    
    private String testo;
    
    
    
 
    

    
    
        public Recensione(){
        
            
            this.titoloRecensione = "";
            
            this.testo = "";
            
            this.dataInserimentoRecensione = null ;
            
            this.username = "";
            
           
        
        }
        
        public String getTitoloRecensione() {
 
            return titoloRecensione;
        }

    
        public void setTitoloRecensione(String titoloRecensione) {
            
            this.titoloRecensione = titoloRecensione;
        }

    
        public String getTesto() {
            
            return testo;
        }

    
        public void setTesto(String testo) {
            
            this.testo = testo;
        }

    
        public Date getDataInserimentoRecensione() {
        
            return dataInserimentoRecensione;
        }

    
        public void setDataInserimentoRecensione(Date dataInserimentoRecensione) {
            
            this.dataInserimentoRecensione = dataInserimentoRecensione;
        }

    
        public String getUsername() {
            
            return username;
        }

    
        public void setUsername(String username) {
            
            this.username = username;
        }

    
}
