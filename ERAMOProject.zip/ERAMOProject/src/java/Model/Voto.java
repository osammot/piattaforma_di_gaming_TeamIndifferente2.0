/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author tom
 */
public class Voto   {
    
    
    private int valore;
    
    private String username;
    
    private String nomegioco;
    
        public Voto(){

            
            this.valore=0;
    
            this.username="";
            
            this.nomegioco="";

        }

    
  

    
        public int getValore() {

            return valore;
        }


        public void setValore(int valore) {

            this.valore = valore;
        }


        public String getUsername() {

            return username;
        }


        public void setUsername(String username) {

            this.username = username;
        }


        public String getNomeGioco() {

            return nomegioco;
        }


        public void setNomeGioco(String gioco) {

            this.nomegioco = gioco;
        }

}
