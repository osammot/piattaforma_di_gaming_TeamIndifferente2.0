/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;


import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.DefaultObjectWrapperBuilder;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;


import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author tom
 */
public class TemplateResult {
    
    public Configuration cfg ;
    public  ServletContext context;
    
    public TemplateResult(ServletContext context) throws IOException{
        
        this.context = context ;
        
        cfg = new Configuration(Configuration.VERSION_2_3_25);
        
        DefaultObjectWrapperBuilder builder = new DefaultObjectWrapperBuilder(Configuration.VERSION_2_3_25);
        
        cfg.setOutputEncoding("UTF-8");
        
        cfg.setObjectWrapper(builder.build());
        
        cfg.setServletContextForTemplateLoading(context, "templates");
    }
    
    public Map getRequestDataModel(HttpServletRequest request) {
        Map datamodel = new HashMap();
     
        Enumeration attrs = request.getAttributeNames();
        
        
        
        while (attrs.hasMoreElements()) {
            ;
            String attrname = (String) attrs.nextElement();
          
            datamodel.put(attrname, request.getAttribute(attrname));
           
        }
        
        return datamodel;
    }
    
    
    public void activate(String tplname, HttpServletRequest request, HttpServletResponse response) throws ParseException, IOException, UnsupportedEncodingException, MalformedTemplateNameException, TemplateException  {
        Map datamodel = getRequestDataModel(request);
        activate1(tplname, datamodel, (OutputStream) response);
    }
    
    public void activate1(String tplname, Map datamodel, OutputStream out) throws UnsupportedEncodingException, ParseException, IOException, MalformedTemplateNameException, TemplateException  {
      
        
        
            process(tplname, datamodel, new OutputStreamWriter(out));
    }
    
    
    public void process(String tplname, Map datamodel, Writer out) throws MalformedTemplateNameException, ParseException, IOException, TemplateException  {
        Template t;
       
        Map<String, Object> localdatamodel = new HashMap();
       
       
        localdatamodel.putAll(datamodel);
        
             
              
                t = cfg.getTemplate("index.html");
               
                localdatamodel.put("content_tpl", tplname);
                
            
           
            t.process(localdatamodel, out);
       
    }
    }
    
    

