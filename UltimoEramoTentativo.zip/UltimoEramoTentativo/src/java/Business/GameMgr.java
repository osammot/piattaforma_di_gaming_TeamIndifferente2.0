/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import DAO.DaoFactory;
import MODEL.Game;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author tom
 */
public class GameMgr {
    
    private DaoFactory dbFactory ;  
    
    
    
    private GameMgr() throws Exception{
    dbFactory = DaoFactory.getDaoFactory(1);
    }
    
    
    public static GameMgr getInstance()throws Exception{
    
    return new GameMgr();
    
    }
    
    public List<Game> getGames() throws Exception{
    
        List<Game> listgames = dbFactory.getGiocoDao().loadAll();
    
        return listgames;

    }
    
    public Game getGame(String titlegame) throws Exception{
    
        Game game =(Game) dbFactory.getGiocoDao().load(titlegame);
        
        return game;
    
    }
    
    public void insertVote(String username,String titologioco,int voto) throws Exception{

        dbFactory.getGiocoDao().voto(username, titologioco, voto);
    
    }
    
    public void insertGame(Game game) throws SQLException{
    
        dbFactory.getGiocoDao().create(game);
    
    }
    
}
