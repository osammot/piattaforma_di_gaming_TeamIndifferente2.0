/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import DAO.DaoFactory;
import MODEL.Image;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tom
 */
public class ImageMgr {
 
    
    private DaoFactory dbfactory ;
    
    private ImageMgr()throws Exception{
    
        dbfactory = DaoFactory.getDaoFactory(1);
    
    }
    
    public static ImageMgr getIstance()throws Exception{
    
        return new ImageMgr();
    
    }
    
    
    public List<Image> listImage() throws SQLException{
    
        List<Image> listimage = dbfactory.getImmagineDao().loadAll();
        
        
        return listimage;
    }
    
    
    public int insertimage(Image image) throws SQLException{
    
        return dbfactory.getImmagineDao().create(image);
    
    }
    
    public void removeimage(Image image) throws SQLException{
    
        dbfactory.getImmagineDao().remove(image);
    
    }
    
    public void updateimage(Image image) throws SQLException{
    
        dbfactory.getImmagineDao().store(image);
        
    }
    
}
