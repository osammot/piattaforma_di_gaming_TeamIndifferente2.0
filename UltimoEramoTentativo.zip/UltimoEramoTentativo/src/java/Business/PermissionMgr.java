package Business;

import DAO.DaoFactory;
import MODEL.Service;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

public class PermissionMgr {
    
    
    private DaoFactory dbfactory ;
    
    private PermissionMgr()throws Exception{
    
        dbfactory = DaoFactory.getDaoFactory(1);
    
    }
    
    public static PermissionMgr getIstance()throws Exception{
    
        return new PermissionMgr();
    
    }
    
    public List<Service> getListService(String username) throws Exception{
    
        List<Service> list = dbfactory.getPermissionHandlerDao().listapermessi(username);
    
        return list;
        
    }
    
    public boolean isPermitted(List<Service> listservice,String service){
    
   
        Iterator <Service> it = listservice.iterator();
        while(it.hasNext()){
            if(it.next().getName().equals(service)){
                return true;
            }
        }
    
    return false;
    }
    
    
   
    public void addServiceToGroup(int serv, int group) throws SQLException{
    
        dbfactory.getServiceDao().addServiceToGroup(serv, group);
    
    }
}
