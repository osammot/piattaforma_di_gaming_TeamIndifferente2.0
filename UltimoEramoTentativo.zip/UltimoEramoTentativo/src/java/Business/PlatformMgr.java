
package Business;

import DAO.DaoFactory;
import java.sql.SQLException;
import java.util.List;
import MODEL.LevelI;



public class PlatformMgr {
  
     private DaoFactory dbFactory = DaoFactory.getDaoFactory(1);  
    
    
    
    private PlatformMgr(){
    
    }
    
    
    public static PlatformMgr getInstance()throws Exception{
    
    return new PlatformMgr();
    
    }

    
    public LevelI getLevel(int numlevel) throws Exception{
   
        return (LevelI) dbFactory.getLivelloDao().load(numlevel);

    }

  
    public List<LevelI> LoadAllLevel() throws SQLException{
   
        List<LevelI> listlevels= dbFactory.getLivelloDao().loadAll();
   
        return listlevels;
    }
   
    public int insertLevel(LevelI level) throws SQLException{
   
       return  dbFactory.getLivelloDao().create(level);
   
    }
   
}
