/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import DAO.DaoFactory;
import MODEL.Review;
import java.util.List;

/**
 *
 * @author tom
 */
public class ReviewMgr {
    
    
    private DaoFactory dbfactory = DaoFactory.getDaoFactory(1);
    
    
    private ReviewMgr(){
    
        
    }

    public static ReviewMgr getIstance()throws Exception{
    
        return new ReviewMgr();
    
    }

    
    public List getListReview(String game)throws Exception{
    
        List<Review> listrev = dbfactory.getRecensioneDao().listaRecensioni(game);
        
        return listrev;
    }
    
    public int insertReview(Review review)throws Exception{
    
        int id = dbfactory.getRecensioneDao().create(review);
    
        return id;
    
    }
    
    public List getListReviewBO() throws Exception{
    
     
        List<Review> listrev = dbfactory.getRecensioneDao().loadAll();
     
        return listrev;
    
    }
    
    public void removeReview(int id) throws Exception{
    
        dbfactory.getRecensioneDao().remove(id);
    
    }
    
    
    public void acceptReview(int id) throws Exception{
    
        dbfactory.getRecensioneDao().store(id);
    
    }
    
}
