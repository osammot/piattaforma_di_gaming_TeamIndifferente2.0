package Business;

import DAO.DaoFactory;
import MODEL.Trophy;
import java.sql.SQLException;
import java.util.List;

public class TrofeoMgr {
    
    private DaoFactory dbfactory = DaoFactory.getDaoFactory(1);
    
    
    private TrofeoMgr(){
    
        
    }

    public static TrofeoMgr getIstance()throws Exception{
    
        return new TrofeoMgr();
    
    }
    
    
    public List<Trophy> getListaTrofei() throws SQLException{
    
        return dbfactory.getTrofeoDao().loadAll();
    
    }
    
    public int createTrofeo(Trophy trofeo) throws SQLException{
    
        return dbfactory.getTrofeoDao().create(trofeo);
        
    }
    
    public void removeTrofeo(Trophy trofeo) throws SQLException{
        
        dbfactory.getTrofeoDao().remove(trofeo);
        
    }
    
    public void storeTrofeo(Trophy trofeo) throws SQLException{
    
        dbfactory.getTrofeoDao().store(trofeo);
    
    }
}
