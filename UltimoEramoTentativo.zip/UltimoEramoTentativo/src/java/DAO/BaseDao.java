/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import EXCEPTION.DatabaseException;
import java.sql.*;
import java.util.List;

/**
 *
 * @author tom
 */
public interface BaseDao {


    public List loadAll() throws SQLException;
    
    public int create(Object object)throws SQLException ;
    
    public Object load(Object key) throws SQLException;
    
    public void store(Object object)throws SQLException ;
    
    public void remove(Object key) throws SQLException ;
    
    public abstract Connection getConnection() throws SQLException,ClassNotFoundException,IllegalAccessException,InstantiationException ;
    
    public abstract void closeDbConnection(ResultSet rs,  Statement stmt,  Connection conn) throws SQLException ;
    
}
