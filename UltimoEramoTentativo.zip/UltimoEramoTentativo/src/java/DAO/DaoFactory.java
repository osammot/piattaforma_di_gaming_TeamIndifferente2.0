/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import DAOMySql.MySqlDaoFactory;
import EXCEPTION.DatabaseException;

/**
 *
 * @author tom
 */
public abstract class DaoFactory {
    
    
    public static final int MYSQL = 1;
    
    
    public abstract LivelloDao getLivelloDao();
    public abstract TrofeoDao getTrofeoDao();
    public abstract UserDao getUserDao() throws DatabaseException;
    public abstract GiocoDao getGiocoDao();
    public abstract ImmagineDao getImmagineDao();
    public abstract RecensioneDao getRecensioneDao();
    public abstract PartitaDao getPartitaDao();
    public abstract RankDao getRankDao();
    public abstract PermissionHandlerDao getPermissionHandlerDao();
    public abstract GroupDao getGroupDao();
    public abstract ServiceDao getServiceDao();
    public abstract GroupServiceDao getGroupServiceDao();
    public abstract UserGroupDao getUserGroupDao();
    public static DaoFactory getDaoFactory(int factoryType)  {
    
        
        switch (factoryType)  {
        
            case MYSQL:
                return new MySqlDaoFactory();
            
            default:
                return null;
        }
    }
}


