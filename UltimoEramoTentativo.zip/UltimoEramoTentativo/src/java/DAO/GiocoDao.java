package DAO;

import java.sql.SQLException;

public interface GiocoDao extends BaseDao{

    void setMediaVoto(String titoloGioco) throws SQLException;

    void voto(String username, String titologioco, int vote) throws SQLException;
    
}
