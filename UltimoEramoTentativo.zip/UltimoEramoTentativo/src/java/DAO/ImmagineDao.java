/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import MODEL.Image;
import java.sql.SQLException;

/**
 *
 * @author tom
 */
 public interface ImmagineDao extends BaseDao {
   
     
     public Image getImageGame(String titologioco) throws SQLException;
     
}
