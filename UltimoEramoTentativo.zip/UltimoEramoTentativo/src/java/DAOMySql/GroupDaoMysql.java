package DAOMySql;

import DAO.GroupDao;
import EXCEPTION.DatabaseException;
import MODEL.Group;
import MODEL.Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tom
 */
public class GroupDaoMysql implements GroupDao{

    @Override
    public List loadAll() throws SQLException {
      
    List<Group> listgroup = new ArrayList();
    
    try {
            PreparedStatement   sListLevel = this.getConnection().prepareStatement("SELECT * FROM gruppo");
            
            
            ResultSet list = sListLevel.executeQuery();
            
            while(list.next()){
            
                Group group = new Group();
                group.setName(list.getString("name"));
                group.setIdgroup(list.getInt("ID_GROUP"));
                
                listgroup.add(group);
                
            }
    }  catch (SQLException ex) {
            Logger.getLogger(LivelloDaoMySql.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return listgroup;
    }

    
    
    @Override
    public List<Group> loadAllForMod() throws Exception{
     
    
        List<Group> listgroup = new ArrayList();
    
    try {
            PreparedStatement   sListLevel = this.getConnection().prepareStatement("SELECT * FROM gruppo where name <> 'admin'");
            
            
            ResultSet list = sListLevel.executeQuery();
            
            while(list.next()){
            
                Group group = new Group();
                group.setName(list.getString("name"));
                group.setIdgroup(list.getInt("ID_GROUP"));
                
                listgroup.add(group);
                
            }
    }  catch (SQLException ex) {
            Logger.getLogger(LivelloDaoMySql.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    return listgroup;
    }
     
     
    
    @Override
    public int create(Object object) throws SQLException {
    
        Group group = (Group)object;
        
        
        
          try {
            PreparedStatement a = this.getConnection().prepareStatement("insert into gruppo(name) value (?)",Statement.RETURN_GENERATED_KEYS);
            
            a.setString(1, group.getName());
            a.execute();
            
            ResultSet rs = a.getGeneratedKeys();
            
            if(rs.next()){
            
            return rs.getInt(1);
            }
        } catch (SQLException ex) {
            throw new DatabaseException("errore inserimento");
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          return 0;
    }

    @Override
    public Object load(Object key) throws SQLException {
    
         int id = (Integer) key ;
        Group group = new Group(); 
        try {
            PreparedStatement  selectgroup = this.getConnection().prepareStatement("select * from gruppo where ID_GROUP = ?");
            
            selectgroup.setInt(1, id);
            
            ResultSet rs = selectgroup.executeQuery();
            
            if(rs.next()){
            
                group.setName(rs.getString("NAME"));
                group.setIdgroup(id);
            
            }
            
            return group ;
            
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(ServiceDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    
        throw new DatabaseException("impossibile caricare gruppo") ;
    
    }

    @Override
    public void store(Object object) throws SQLException {
    
         try {
            Group gruppo = (Group) object ;
            
            PreparedStatement storegroup = this.getConnection().prepareStatement(" update gruppo set name = ? where ID_GROUP = ?");
            
            storegroup.setString(1, gruppo.getName());
            storegroup.setInt(2, gruppo.getIdgroup());
            
            storegroup.execute();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(ServiceDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void remove(Object key) throws SQLException {
    
        try {
            Group id = (Group)key ;
            
            
            PreparedStatement   deletegroup = this.getConnection().prepareStatement("delete FROM gruppo where ID_GROUP= ?");
            
            deletegroup.setInt(1, id.getIdgroup());
            
            deletegroup.execute();
            
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    
    @Override
    public Connection getConnection() throws SQLException,ClassNotFoundException,IllegalAccessException,InstantiationException
    {    
        Connection conn = MySqlDaoFactory.getConnection();
        return conn;
    }

    @Override
    public void closeDbConnection(ResultSet rs, Statement stmt, Connection conn) {
        MySqlDaoFactory.closeDbConnection(rs, stmt, conn);
    }
    
}
