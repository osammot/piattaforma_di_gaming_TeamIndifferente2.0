/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySql;

import DAO.GroupServiceDao;
import MODEL.Group;
import MODEL.GroupService;
import MODEL.GroupServiceImpl;
import MODEL.Service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tom
 */
public class GroupServiceMySql implements GroupServiceDao{

    @Override
    public List loadAll() throws SQLException {
        
        List<GroupService> listGroupService = new ArrayList<>();
        
        try {
            PreparedStatement all = this.getConnection().prepareStatement(" select * from groupservice ");
       
           ResultSet rs = all.executeQuery();
           
           while(rs.next()){
           
               GroupService groupservice = new GroupServiceImpl();
                              
               groupservice.setIDgroupservice(rs.getInt("ID"));
               
               groupservice =(GroupService) this.load(groupservice);
               
               listGroupService.add(groupservice);
           }
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupServiceMySql.class.getName()).log(Level.SEVERE, null, ex);
        }
          return listGroupService;
    }

    @Override
    public int create(Object object) throws SQLException {
       
        GroupService groupservice =  (GroupServiceImpl) object ;
     
        
        System.out.println("idService :" + groupservice.getService().getIdService() );
        System.out.println("idGroup :" + groupservice.getGroup().getIdgroup());
        try {
            PreparedStatement add = this.getConnection().prepareStatement(" INSERT INTO groupservice(ID_GROUP,ID_SERVIZI) VALUE (?,?)");
            
            add.setInt(2,groupservice.getGroup().getIdgroup());
            
            add.setInt(1, groupservice.getService().getIdService());
            
            
            System.out.println(add);
            add.execute();
        
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(ServiceDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }

    @Override
    public Object load(Object key) throws SQLException {
    
        GroupService groupservice = (GroupService) key;
        
        PreparedStatement stat;
        try {
            stat = this.getConnection().prepareStatement("select * from groupservice where id = ?");
        
            stat.setInt(1, groupservice.getIDgroupservice());
            
            ResultSet rs = stat.executeQuery();
            
            if(rs.next()){
            
                Group group = (Group) new GroupDaoMysql().load(rs.getInt("ID_GROUP"));

                Service service = (Service) new ServiceDaoMysql().load(rs.getInt("ID_SERVIZI"));

                
                groupservice.setGroup(group);

                groupservice.setService(service);
            
            
            }
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(GroupServiceMySql.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
       

        return groupservice ;
    
    }

    @Override
    public void store(Object object) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remove(Object key) throws SQLException {
    
        GroupService groupservice = (GroupService) key ;
            
        try {
            PreparedStatement removegroupservice = this.getConnection().prepareStatement(" delete from groupservice where ID = ?");
        
            removegroupservice.setInt(1, groupservice.getIDgroupservice());
            removegroupservice.execute();
        
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException ex) {
            Logger.getLogger(ServiceDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    @Override
    public Connection getConnection() throws SQLException, ClassNotFoundException, IllegalAccessException, InstantiationException {
    
         Connection conn = MySqlDaoFactory.getConnection();
       
         return conn;
        
    }

    @Override
    public void closeDbConnection(ResultSet rs, Statement stmt, Connection conn) throws SQLException {
    
        MySqlDaoFactory.closeDbConnection(rs, stmt, conn);
    
    }
    
}
