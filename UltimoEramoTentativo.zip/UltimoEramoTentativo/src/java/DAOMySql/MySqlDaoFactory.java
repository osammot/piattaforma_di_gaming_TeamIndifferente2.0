/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySql;

import DAO.DaoFactory;
import DAO.GiocoDao;
import DAO.GroupDao;
import DAO.GroupServiceDao;
import DAO.ImmagineDao;
import DAO.LivelloDao;
import DAO.PartitaDao;
import DAO.PermissionHandlerDao;
import DAO.RankDao;
import DAO.RecensioneDao;
import DAO.ServiceDao;
import DAO.TrofeoDao;
import DAO.UserDao;
import DAO.UserGroupDao;
import EXCEPTION.DatabaseException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author tom
 */
public class MySqlDaoFactory extends DaoFactory {

    public static Connection getConnection() throws DatabaseException{
         
        Connection connection = null ;
        try {
            
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            
            
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gameplatform", "root", "root");
            
            
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | SQLException ex) {
            throw new DatabaseException("errore connessione");
        }
        return connection;
    }

    static void closeDbConnection(ResultSet rs, Statement stmt, Connection conn) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public MySqlDaoFactory() {
    }

    @Override
    public LivelloDao getLivelloDao() {
        
        return new LivelloDaoMySql();
    
    }

    @Override
    public TrofeoDao getTrofeoDao() {
    
        return new TrofeoDaoMySql();
    
    }

    @Override
    public UserDao getUserDao() throws DatabaseException{
    
        return new UserDaoMySql();
    
    }

    @Override
    public GiocoDao getGiocoDao() {
    
        return new GiocoDaoMySql();
    
    }

    @Override
    
    public ImmagineDao getImmagineDao() {
    
        return new ImmagineDaoMySql();
    }

    @Override
    public RecensioneDao getRecensioneDao() {
        
        return new RecensioneDaoMySql();
    
    }

    @Override
    public PartitaDao getPartitaDao() {
    
        return new PartitaDaoMySql();
    
    }

    @Override
    public RankDao getRankDao() {
      
        return new RankDaoMysql();
        
    }

    @Override
    public PermissionHandlerDao getPermissionHandlerDao() {
    
        return new PermissionHandlerDaoMysql();
    }

    @Override
    public GroupDao getGroupDao() {
        return new GroupDaoMysql();
    
    }

    @Override
    public ServiceDao getServiceDao() {
    
        return new ServiceDaoMysql();
    
    }

    @Override
    public GroupServiceDao getGroupServiceDao() {        
    
        return new GroupServiceMySql();
    
    }

    @Override
    public UserGroupDao getUserGroupDao() {
    
        return new UserGroupMySql();
    
    }
    

}
