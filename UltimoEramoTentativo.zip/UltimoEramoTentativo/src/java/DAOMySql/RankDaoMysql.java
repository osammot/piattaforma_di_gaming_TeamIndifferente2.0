/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMySql;


import DAO.RankDao;
import EXCEPTION.DatabaseException;
import MODEL.Match;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author tom
 */
public class RankDaoMysql implements RankDao{

    @Override
    public List loadAll() throws DatabaseException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int create(Object object)  throws DatabaseException {

        int key =0;
        
        try {
            
            PreparedStatement insertRank = this.getConnection().prepareStatement("insert into rank value (0,?,0)");
            
            String username = (String)object ;
            
            insertRank.setString(1, username);
                       
            insertRank.executeUpdate();
            
            
            
            
        } catch (SQLException ex) {
           throw new DatabaseException("as");
        } catch (Exception ex) {
            Logger.getLogger(RankDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return key;
    }

    @Override
    public Object load(Object key)  throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void store(Object object)  throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void remove(Object key) throws SQLException {
     
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    }

    @Override
    public Connection getConnection()  throws SQLException{
       
        Connection conn = MySqlDaoFactory.getConnection();
        
        return conn;
    
    }

    @Override
    public void closeDbConnection(ResultSet rs, Statement stmt, Connection conn) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int recuperaNumeroLivello(String username) throws Exception {
    
            int numberlvl = 0;
         try {
            PreparedStatement sNumberLvl = this.getConnection().prepareStatement("SELECT numberlevel FROM rank WHERE username = ?");
            sNumberLvl.setString(1, username);
            ResultSet rs = sNumberLvl.executeQuery();
            
            if(rs.next()){
            
                numberlvl = rs.getInt("numberlevel");
               
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(RankDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         return numberlvl;
    }

    @Override
    public int recuperaPunteggioTotale(String username) throws Exception {
       
        int totalpoint = 0;
        
        try {    
            PreparedStatement sNumberLvl = this.getConnection().prepareStatement("SELECT point FROM rank WHERE username = ?");
            
            ResultSet rs = sNumberLvl.executeQuery();
            
            if(rs.next()){
            
                totalpoint = rs.getInt("point");
               
            }
            
        } catch (SQLException ex) {
        
        //gestire eccezzioneeeeeee
        }
        return totalpoint;
        
    }

    @Override
    public void updatePoint(Match match) throws Exception {
    
        try {
            
            PreparedStatement uPoint = this.getConnection().prepareStatement("UPDATE rank set point = ? where username = ? ");
            
            uPoint.setInt(1, match.getPunteggiototale());
        
            uPoint.setString(2, match.getUsername());
            
            uPoint.execute();
        } 
        catch (SQLException ex) {
        
            Logger.getLogger(RankDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        
        }
    
    }

    @Override
    public void updateLevel(Match match)  throws Exception{
     
        try {
            
            PreparedStatement uPoint = this.getConnection().prepareStatement("UPDATE rank set numberlevel = ? where username = ? ");
            
            uPoint.setInt(1, match.getLivello().getLevelnumber()+1);
        
            uPoint.setString(2, match.getUsername());
        
            uPoint.execute();
        } 
        catch (SQLException ex) {
        
            Logger.getLogger(RankDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        
        }
        
    }
    
    
    public Map<String,Integer> getRanking() throws Exception{
    
        Map<String,Integer> mappa = new LinkedHashMap<>();
        try {
            
            PreparedStatement sRank = this.getConnection().prepareStatement("SELECT * FROM RANK ORDER BY POINT desc");
            
            ResultSet result = sRank.executeQuery();
            
            while(result.next()){
            
                String username = result.getString("username");
                int point = result.getInt("point");
                mappa.put(username, point);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(RankDaoMysql.class.getName()).log(Level.SEVERE, null, ex);
        }
        return mappa;
    }    
}
