package DAOMySql;

import DAO.UserDao;
import EXCEPTION.DatabaseException;
import MODEL.Group;
import MODEL.User;
import MODEL.UserImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


/**
 *
 * @author tom
 */
public class UserDaoMySql implements UserDao{

    @Override
    public Connection getConnection()  throws DatabaseException{
    
        Connection conn = MySqlDaoFactory.getConnection();
        return conn;
        
    }

    @Override
    public void closeDbConnection(ResultSet rs, Statement stmt, Connection conn) {
    
        MySqlDaoFactory.closeDbConnection(rs, stmt, conn);
    }

    @Override
    public void remove(Object key) throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    /**
    *METODO PER l'inserimento di un utente
    */
    @Override
    public int create(Object object) throws SQLException {
        
        
        int id = 0 ;
        User user = (User) object ;
       
        PreparedStatement insertUser = this.getConnection().prepareStatement("insert into user"
                                                                             + "  (username,name,surname,password,address,email,city )"
                                                                             + " value(?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
        
        
        insertUser.setString(1, user.getUsername());
        insertUser.setString(2, user.getName());
        insertUser.setString(3, user.getSurname());
        insertUser.setString(4, user.getPassword());
        insertUser.setString(5, user.getAddress());
        insertUser.setString(6, user.getEmail());
        insertUser.setString(7, user.getCity());
        
        
                
        if(insertUser.executeUpdate()== 1){
        
        ResultSet rs =  insertUser.getGeneratedKeys();
        
        if(rs.next()){
        
            id = rs.getInt(1);
        }
            System.out.println(id +"valore ritornato");
        }
      
       
        return id ;
    }

    @Override
    public List loadAll() throws SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    /**
    * METODO PER IL RECUPERO DI UN UTENTE DATO LO USERNAME
     * @param username
    *
    * 
    * @return interfaccia user
     * @throws EXCEPTION.DatabaseException
    */
   
    @Override
    public Object load(Object usernameObj) throws SQLException{
      
        User user = new UserImpl();
        int id = (Integer) usernameObj ;
        PreparedStatement stat = this.getConnection().prepareStatement(" SELECT * FROM user left join usergroup on user.id_user = usergroup.ID_USER where user.id_user = ?");
    
        stat.setInt(1, id);
        ResultSet rs = stat.executeQuery();
        
        if(rs.next()){
        
            user.setId(id);
            user.setUsername(rs.getString("username"));
            user.setName(rs.getString("name"));
            user.setSurname(rs.getString("surname"));
            user.setPassword(rs.getString("password"));
            user.setEmail(rs.getString("email"));
            user.setCity(rs.getString("city"));
            Group group = (Group) new GroupDaoMysql().load(rs.getInt("ID_GROUP"));
            user.setGroup(group);
            
            
        }
         
        return user ;
    
    
    }

    @Override
    public void store(Object object)  throws SQLException {
              
    }//end metodo

    @Override
    public int checkLogin(String username, String password) throws Exception {
    
        PreparedStatement stat = this.getConnection().prepareStatement(" SELECT * FROM user  where username = ? and password = ? ");
    
        stat.setString(1, username);
        stat.setString(2, password);
    
        ResultSet rs = stat.executeQuery();
        
        if(rs.next()){
        
            return rs.getInt("id_user");
            
        }
        
        return 0 ;
    }


            
        
    
}
