/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;



/**
 *
 * @author tom
 */

public interface Game {

    float getAverage_vote();

    String getDescription();

    Image getImage();

    String getTemplate();

    String getTitle();

    String getType();

    int getValue();

    void setAverage_vote(float Average_vote);

    void setDescription(String description);

    void setImage(Image image);

    void setTemplate(String template);

    void setTitle(String title);

    void setType(String type);

    void setValue(int value);
    
}
