/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import MODEL.Group;
import MODEL.GroupService;
import MODEL.GroupService;
import MODEL.GroupService;
import MODEL.Service;
import MODEL.Service;

/**
 *
 * @author tom
 */
public class GroupServiceImpl implements GroupService {
    
    private Group group ;
    
    private Service service ;

    private int IDgroupservice ;
    
    public GroupServiceImpl(){

        this.group = new Group();
    
        this.service = new Service();
    
        this.IDgroupservice = 0 ;
    }

    @Override
    public Group getGroup() {
        return group;
    }

    @Override
    public void setGroup(Group group) {
        this.group = group;
    }

    @Override
    public Service getService() {
        return service;
    }

    @Override
    public void setService(Service service) {
        this.service = service;
    }

    @Override
    public int getIDgroupservice() {
        return IDgroupservice;
    }

    @Override
    public void setIDgroupservice(int IDgroupservice) {
        this.IDgroupservice = IDgroupservice;
    }
    
    
    
}