package MODEL.IMPL;

import MODEL.Game;
import MODEL.Game;
import MODEL.Game;
import MODEL.Game;
import MODEL.Image;
import MODEL.Image;
import MODEL.Image;
import MODEL.Image;

public class GameImpl  implements Game  {  
    
    private String title;
    
    private String type;
    
    private float Average_vote;
    
    private String description;
    
    private int value;
    
    private String template;
    
    private Image image;

    
    
    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    @Override
    public float getAverage_vote() {
        return Average_vote;
    }

    @Override
    public void setAverage_vote(float Average_vote) {
        this.Average_vote = Average_vote;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String getTemplate() {
        return template;
    }

    @Override
    public void setTemplate(String template) {
        this.template = template;
    }

    @Override
    public Image getImage() {
        return image;
    }

    @Override
    public void setImage(Image image) {
        this.image = image;
    }
  
    
    

    
}

