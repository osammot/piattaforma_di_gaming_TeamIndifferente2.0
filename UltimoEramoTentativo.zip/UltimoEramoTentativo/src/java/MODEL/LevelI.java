/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
 *
 * @author tom
 */
public interface LevelI {

    int getLevelnumber();

    int getPointnextlevel();

    Trophy getTrophy();

    void setLevelnumber(int levelnumber);

    void setPointnextlevel(int pointnextlevel);

    void setTrophy(Trophy trophy);
    
    public int getId_level() ;
    
    public void setId_level(int id_level);
    
}
