/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import java.util.Date;

/**
 *
 * @author tom
 */
public interface Review {
    
    Date getDate();

    int getId_review();

    String getTextreview();

    String getTitlegame();

    String getTitlereview();

    String getUsername();

    void setDate(Date date);

    void setId_review(int id_review);

    void setTextreview(String textreview);

    void setTitlegame(String titlegame);

    void setTitlereview(String titlereview);

    void setUsername(String username);
}
