/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import MODEL.Review;
import MODEL.Review;
import MODEL.Review;
import java.util.Date;

/**
 *
 * @author tom
 */
public class ReviewImpl implements Review{
    
    
     private int id_review;
    
    private String titlereview;
    
    
    private String textreview;
        
    private String username;
        
    private String titlegame;
    
    private Date date;
    public ReviewImpl(String titolorec ,String message,String username, String titlegame){
        
        this.titlereview =titolorec;
        this.textreview= message;
        this.username=username;
        this.titlegame=titlegame;
    }
    public ReviewImpl(){
        
            this.id_review = 0;
            
            this.titlereview = "";
            
            this.textreview = "";
            
            this.date = null ;
            
            this.username = "";
            
            this.titlegame="";
           
        
        }

    @Override
    public int getId_review() {
        return id_review;
    }

    @Override
    public void setId_review(int id_review) {
        this.id_review = id_review;
    }

    @Override
    public String getTitlereview() {
        return titlereview;
    }

    @Override
    public void setTitlereview(String titlereview) {
        this.titlereview = titlereview;
    }

    @Override
    public String getTextreview() {
        return textreview;
    }

    @Override
    public void setTextreview(String textreview) {
        this.textreview = textreview;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getTitlegame() {
        return titlegame;
    }

    @Override
    public void setTitlegame(String titlegame) {
        this.titlegame = titlegame;
    }

    @Override
    public Date getDate() {
        return date;
    }

    @Override
    public void setDate(Date date) {
        this.date = date;
    }
    
}
