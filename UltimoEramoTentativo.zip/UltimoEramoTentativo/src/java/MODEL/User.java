/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
 *
 * @author tom
 */
public interface User {

    String getAddress();

    String getCity();

    String getEmail();

    String getName();

    String getPassword();

    String getSurname();

    String getUsername();
    
    Group getGroup() ;
    
    int getId();
    
     void setUsername(String username) ;

     void setName(String name) ;

     void setSurname(String surname) ;

     void setPassword(String password) ;

     void setAddress(String address);

     void setEmail(String email) ;

     void setCity(String city);

     void setId(int id) ;

     void setGroup(Group group);


}
