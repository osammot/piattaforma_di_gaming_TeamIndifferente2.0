/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

import MODEL.Group;
import MODEL.User;
import MODEL.User;
import MODEL.User;
import MODEL.UserGroup;
import MODEL.UserGroup;
import MODEL.UserGroup;

/**
 *
 * @author tom
 */
public class UserGroupImpl implements UserGroup {
    
    
    private int id ;
    
    private User user ;
    
    private Group group ;
    
    
    
    public UserGroupImpl(){
    
        this.id = 0 ;
        
        this.user = null ;
        
        this.group = null ;
        
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public User getUser() {
        return user;
    }

    @Override
    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public Group getGroup() {
        return group;
    }

    @Override
    public void setGroup(Group group) {
        this.group = group;
    }



}
