package UTIL;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Web application lifecycle listener.
 *
 * @author tom
 */
public class NewServletListener implements HttpSessionListener {

    @Override
    public void sessionCreated(HttpSessionEvent se) {
       System.out.println("sessione creata con listener aaaa    sss");
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
       System.out.println("sessione distrutta con listener aaa ssss"); //To change body of generated methods, choose Tools | Templates.
    }
}
