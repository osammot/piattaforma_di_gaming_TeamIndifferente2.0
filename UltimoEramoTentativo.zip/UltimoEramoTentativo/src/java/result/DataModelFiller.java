/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package result;

import java.util.Map;

/**
 *
 * @author metantz
 */
public interface DataModelFiller {

    public void fillDataModel(Map datamodel);
}
